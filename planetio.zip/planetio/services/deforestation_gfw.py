# -*- coding: utf-8 -*-
import os
import json
import time
import logging
import requests
from typing import Any, Dict, List, Optional
from .deforestation_base import DeforestationProvider

_logger = logging.getLogger(__name__)

class GFWProvider(DeforestationProvider):
    name = "gfw"
    # Endpoints kept configurable to avoid tight coupling to a specific base URL/version.
    # You can override via Odoo ir.config_parameter if desired.
    DEFAULT_GEOSTORE_URL = os.environ.get("GFW_GEOSTORE_URL", "https://api.resourcewatch.org/v1/geostore")
    DEFAULT_SQL_URL = os.environ.get("GFW_SQL_URL", "https://data-api.globalforestwatch.org/datasets/{dataset}/latest/query")
    DEFAULT_DATASET = os.environ.get("GFW_DATASET", "gfw_integrated_alerts")

    def __init__(self, token: Optional[str] = None, dataset: Optional[str] = None,
                 geostore_url: Optional[str] = None, sql_url: Optional[str] = None) -> None:
        self.token = token or os.environ.get("GFW_TOKEN")
        self.dataset = dataset or self.DEFAULT_DATASET
        self.geostore_url = geostore_url or self.DEFAULT_GEOSTORE_URL
        self.sql_url = sql_url or self.DEFAULT_SQL_URL

    def _headers(self) -> Dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def _create_geostore(self, aoi_geojson: Dict[str, Any]) -> str:
        payload = {"geojson": aoi_geojson}
        r = requests.post(self.geostore_url, headers=self._headers(), json=payload, timeout=60)
        if r.status_code not in (200, 201):
            raise RuntimeError(f"GFW geostore error {r.status_code}: {r.text[:200]}")
        data = r.json()
        geostore_id = data.get("data", {}).get("id") or data.get("data", {}).get("attributes", {}).get("hash")
        if not geostore_id:
            raise RuntimeError("GFW geostore: unable to parse geostore id")
        return geostore_id

    def _query_alerts(self, geostore_id: str, start_date: Optional[str], end_date: Optional[str]) -> List[Dict[str, Any]]:
        # Build SQL. Column names may evolve; these are common ones for integrated alerts.
        date_filter = ""
        if start_date and end_date:
            date_filter = f"WHERE alert__date >= '{start_date}' AND alert__date < '{end_date}'"
        elif start_date:
            date_filter = f"WHERE alert__date >= '{start_date}'"
        elif end_date:
            date_filter = f"WHERE alert__date < '{end_date}'"

        sql = (
            "SELECT alert__date AS date, "
            "       area__ha AS area_ha, "
            "       latitude  AS lat, "
            "       longitude AS lon, "
            "       'gfw_integrated' AS source "
            f"FROM {self.dataset} "
            f"{date_filter}"
        )
        url = self.sql_url.format(dataset=self.dataset)
        params = {"sql": sql, "geostore": geostore_id}
        r = requests.get(url, headers=self._headers(), params=params, timeout=120)
        if r.status_code != 200:
            raise RuntimeError(f"GFW SQL error {r.status_code}: {r.text[:200]}")
        resp = r.json()
        rows = resp.get("data") or resp.get("rows") or []
        # Normalize field names
        alerts = []
        for row in rows:
            alerts.append({
                "date": row.get("date") or row.get("alert__date"),
                "area_ha": float(row.get("area_ha") or row.get("area__ha") or 0) if row.get("area_ha") or row.get("area__ha") else None,
                "lat": float(row.get("lat") or row.get("latitude") or 0) if row.get("lat") or row.get("latitude") else None,
                "lon": float(row.get("lon") or row.get("longitude") or 0) if row.get("lon") or row.get("longitude") else None,
                "source": "gfw_integrated",
            })
        return alerts

    def _aggregate(self, alerts: List[Dict[str, Any]]) -> Dict[str, Any]:
        count = len(alerts)
        area_total = sum(a.get("area_ha") or 0 for a in alerts)
        # group by date
        by_date = {}
        for a in alerts:
            d = a.get("date") or "unknown"
            by_date[d] = by_date.get(d, 0) + 1
        return {
            "alert_count": count,
            "area_ha_total": area_total,
            "alerts_by_date": by_date,
        }

    def get_status(self, aoi_geojson: Dict[str, Any], start_date: Optional[str] = None,
                   end_date: Optional[str] = None, **kwargs) -> Dict[str, Any]:
        geostore_id = self._create_geostore(aoi_geojson)
        alerts = self._query_alerts(geostore_id, start_date, end_date)
        metrics = self._aggregate(alerts)
        return {
            "alerts": alerts,
            "metrics": metrics,
            "meta": {
                "provider": self.name,
                "geostore_id": geostore_id,
                "dataset": self.dataset
            }
        }
