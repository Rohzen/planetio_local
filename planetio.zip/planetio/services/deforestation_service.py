# -*- coding: utf-8 -*-
import logging
from typing import Any, Dict, Optional
from odoo import models, api
from .deforestation_base import DeforestationProvider
from .deforestation_gfw import GFWProvider

_logger = logging.getLogger(__name__)

# Optional providers (stubs for now). Uncomment when implemented.
try:
    from .deforestation_inpe import INPEProvider  # noqa: F401
except Exception:  # pragma: no cover
    INPEProvider = None

try:
    from .deforestation_mapbiomas import MapBiomasProvider  # noqa: F401
except Exception:  # pragma: no cover
    MapBiomasProvider = None

PROVIDER_REGISTRY = {
    "gfw": GFWProvider,
    # "inpe": INPEProvider,
    # "mapbiomas": MapBiomasProvider,
}


class DeforestationService(models.AbstractModel):
    _name = "planetio.deforestation.service"
    _description = "Provider-agnostic deforestation analysis service"

    def _get_param(self, key: str, default: Any = None) -> Any:
        return self.env["ir.config_parameter"].sudo().get_param(key, default)

    def _build_provider(self, name: Optional[str] = None) -> DeforestationProvider:
        provider_name = (name or self._get_param("planetio.deforestation_provider", "gfw")).lower()
        cls = PROVIDER_REGISTRY.get(provider_name, GFWProvider)
        if provider_name == "gfw":
            auth_mode = (self._get_param("planetio.gfw_auth_mode", "token") or "token").lower()
            dataset = self._get_param("planetio.gfw_dataset", None)
            geostore_url = self._get_param("planetio.gfw_geostore_url", None)
            sql_url = self._get_param("planetio.gfw_sql_url", None)
            token = None
            if auth_mode == "oauth":
                token_url = self._get_param("planetio.gfw_oauth_token_url", None)
                client_id = self._get_param("planetio.gfw_oauth_client_id", None)
                client_secret = self._get_param("planetio.gfw_oauth_client_secret", None)
                scope = self._get_param("planetio.gfw_oauth_scope", None)
                if not all([token_url, client_id, client_secret]):
                    raise ValueError("GFW OAuth is enabled but token_url/client_id/client_secret are not configured.")
                token = self.env['planetio.oauth.manager'].get_token(
                    key_prefix="planetio.gfw_oauth",
                    token_url=token_url,
                    client_id=client_id,
                    client_secret=client_secret,
                    scope=scope,
                )
            else:
                token = self._get_param("planetio.gfw_token", None)
            return cls(token=token, dataset=dataset, geostore_url=geostore_url, sql_url=sql_url)
        # For other providers, pull their specific params here when implemented
        return cls()

    @api.model
    def analyze_geojson(
            self,
            aoi_geojson: Dict[str, Any],
            start_date: Optional[str] = None,
            end_date: Optional[str] = None,
            provider: Optional[str] = None,
            **kwargs
    ) -> Dict[str, Any]:
        """Run a deforestation analysis for the given AOI using the selected provider.

        provider: optional provider key ('gfw', 'inpe', 'mapbiomas'), defaults to system param.
        Returns a normalized dict with alerts, metrics, meta.
        """
        prov = self._build_provider(provider)
        _logger.info("DeforestationService using provider: %s", getattr(prov, 'name', prov.__class__.__name__))
        return prov.get_status(aoi_geojson, start_date=start_date, end_date=end_date, **kwargs)