pip install google-generativeai

Imposta in Parametri di Sistema:

planetio_ai_import.gemini_api_key = <API KEY>

planetio_ai_import.gemini_model = gemini-1.5-pro (opzionale)

Niente cambia nel wizard: quando il matcher non trova header, entra il fallback Gemini e compila “source: gemini” con “score”.